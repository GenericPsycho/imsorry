import { debug } from "@src/engine/utils/Logger"

export default async function () {
	debug("Loading WS handlers")
	// TODO: Load WS handlers
}