import { info } from "../utils/Logger";

export default async function() {
	info("Ready");
}