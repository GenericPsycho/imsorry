import "reflect-metadata";
import { init } from "./application";

init();