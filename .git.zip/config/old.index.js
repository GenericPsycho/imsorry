// @ts-check
/** @typedef {import('../src/config/index.ts').default} DefinedConfig */
/** @type {DefinedConfig} */
module.exports = {
	// HTTP Server
	modules: {
		discord: {
			prefix: "!",
			token: process.env.DISCORD_TOKEN,
			defaultEmbedColor: "FF0000",
			activity: {
				type: "PLAYING",
				name: "something",
			  },
		}
	}
};

